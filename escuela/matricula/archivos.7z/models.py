from django.db import models

class Alumno(models.Model):
    dni = models.CharField(max_length=9, primary_key=True)
    nombre = models.CharField(max_length=20)
    apellidos = models.CharField(max_length=60)
    curso = models.ForeignKey('Curso', on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.apellidos}, {self.nombre}"

class Curso(models.Model):
    abrev = models.CharField(max_length=10, primary_key=True)
    denom = models.CharField(max_length=40)

    def __str__(self):
        return self.denom
