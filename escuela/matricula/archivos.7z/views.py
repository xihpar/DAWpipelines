from django.shortcuts import render
from .models import Alumno

# Create your views here.
def vista_alumnos(request):
    alumnos = Alumno.objects.all()
    return render(request, "lista_alumnos.html", {'alumnos':alumnos})